const myFunction = function(event) {
  console.log('Hooray!!')
}

// Use `document.querySelector()` to obtain a reference to the `#test` element.

// Add an event listener that triggers `myFunction` when the mouse enters the `#test` element.
